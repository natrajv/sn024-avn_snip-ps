# Import the module (path to folder)
Import-Module "$PSScriptRoot\HelloWorld.psd1" -Force

# Use module functions
Write-Output Get-Msg