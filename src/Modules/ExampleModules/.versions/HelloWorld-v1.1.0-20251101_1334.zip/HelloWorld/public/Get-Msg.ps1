
#--- Public function to get message
function Get-Msg {
		$aa = _GetMsg
		return $aa
}