# Simple PowerShell module 

## Objectives
* Simple PowerShell Module
* Flat directory structure
* .psm1, .psd1, .ps1 file types

## Version
v1.0.0-20251027_0511
* Initial release
---