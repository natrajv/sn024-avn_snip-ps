function _GetMsg {
		return "Hello World! $MY_NAME"
}